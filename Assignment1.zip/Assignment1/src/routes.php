<?php
//hello route
require __DIR__ . '/Controllers/hello.php';

//users route
require __DIR__ . '/Controllers/user.php';