<?php
//get all users
function getAllUsers($db)
{
$sql = 'Select p.username, p.firstname, p.lastname, p.gender from users p ';
$stmt = $db->prepare ($sql);
$stmt ->execute();
return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

//get users by id
function getUser($db, $userId)
{
$sql = 'Select p.username, p.firstname, p.lastname, p.gender from users p ';
$sql .= 'Where p.id = :id';
$stmt = $db->prepare ($sql);
$id = (int) $userId;
$stmt->bindParam(':id', $id, PDO::PARAM_INT);
$stmt->execute();
return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

//delete user by id
function deleteUser($db,$userId) {
    $sql = ' Delete from users where id = :id';
    $stmt = $db->prepare($sql);
    $id = (int)$userId;
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    }

    //update user by id
    function updateUser($db,$form_dat,$userId) {
    $sql = 'UPDATE users SET username = :username , firstname = :firstname ,
    lastname = :lastname , gender = :gender';
    $sql .=' WHERE id = :id';
    $stmt = $db->prepare ($sql);
    $id = (int)$userId;
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->bindParam(':username', $form_dat['username']);
    $stmt->bindParam(':firstname', $form_dat['firstname']);
    $stmt->bindParam(':lastname', $form_dat['lastname']);
    $stmt->bindParam(':gender', $form_dat['gender']);
    $stmt->execute();
    }


    //add new user
    function createUser($db, $form_data) {
            $sql = 'Insert into users (username, firstname, lastname, gender) ';
            $sql .= 'values (:username, :firstname, :lastname, :gender)';
            $stmt = $db->prepare ($sql);
            $stmt->bindParam(':username', $form_data['username']);
            $stmt->bindParam(':firstname', $form_data['firstname']);
            $stmt->bindParam(':lastname', $form_data['lastname']);
            $stmt->bindParam(':gender', $form_data['gender']);
            $stmt->execute();
            return $db->lastInsertID();//insert last number.. continue
            }