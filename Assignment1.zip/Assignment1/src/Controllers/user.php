<?php
use Slim\Http\Request; //namespace
use Slim\Http\Response; //namespace
//include userProc.php file
include __DIR__ . '/function/userProc.php';//read table user
$app->get('/users', function (Request $request, Response $response, array
$arg){
return $this->response->withJson(array('data' => 'success'), 200);
});


// read all data from table users
$app->get('/allusers',function (Request $request, Response $response,array $arg)
{
$data = getAllUsers($this->db);
if (is_null($data)) {
return $this->response->withHeader('Access-Control-Allow-Origin',
 '*')->withJson(array('error' => 'no data'), 404);
}
return $this->response->withJson(array('data' => $data), 200);
});


//request table users by condition (users id)
$app->get('/users/[{id}]', function ($request, $response, $args){
$userId = $args['id'];
if (!is_numeric($userId)) {
return $this->response->withJson(array('error' => 'numeric paremeter required'), 500);
}
$data = getUser($this->db,$userId);
if (empty($data)) {
return $this->response->withJson(array('error' => 'no data'), 500);
}
return $this->response->withJson(array('data' => $data), 200);
});

//add data
$app->post('/users/add', function ($request, $response, $args) {
    $form_data = $request->getParsedBody();
    $data = createUser($this->db, $form_data);
    if ($data <= 0) {
    return $this->response->withJson(array('error' => 'add data fail'), 500);
    }
    return $this->response->withJson(array('add data' => 'success'), 200);
    }
    );


    //delete row
$app->delete('/users/del/[{id}]', function ($request, $response, $args){
    $userId = $args['id'];
    if (!is_numeric($userId)) {
    return $this->response->withJson(array('error' => 'numeric paremeter required'), 422);
    }
    $data = deleteUser($this->db,$userId);
    if (empty($data)) {
    return $this->response->withJson(array($userId=> 'is successfully deleted'), 202);};
    });
    
    //put table users
    $app->put('/users/put/[{id}]', function ($request, $response, $args){
    $userId = $args['id'];
    if (!is_numeric($userId)) {
    return $this->response->withJson(array('error' => 'numeric paremeter required'), 422);
    }
    $form_dat=$request->getParsedBody();
    $data=updateUser($this->db,$form_dat,$userId,);
    if ($data <=0)
    return $this->response->withJson(array('data' => 'successfully updated'), 200);
});